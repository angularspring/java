import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
import { LocationStrategy, HashLocationStrategy, DatePipe } from '@angular/common';
import { NgxSpinnerModule } from 'ngx-spinner';

import { AppComponent } from './app.component';
import { SharedModule } from './modules/common/shared.module';
import { PrimaryModule } from './views/common/primary.module';
import { HTTP_INTERCEPTORS } from '../../node_modules/@angular/common/http';
import { CustomInterceptor } from './services/custom-interceptor.service';
import { ModalComponent } from './views/common/layout/modal.component';


const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = {
  suppressScrollX: true
};

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    SharedModule,
    PrimaryModule,
    NgxSpinnerModule
  ],
  providers: [{
    provide: LocationStrategy,
    useClass: HashLocationStrategy
  },{
    provide: HTTP_INTERCEPTORS,
    useClass: CustomInterceptor,
    multi: true
  },
  DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
