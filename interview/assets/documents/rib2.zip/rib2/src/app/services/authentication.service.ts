import { Injectable } from '@angular/core';
import { Observable, Observer, Subject} from 'rxjs';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  loggedInChange: Observable<boolean>;
  //loggedInChangeObserver: Observer<boolean>;
  private loggedInSubject = new Subject<boolean>();

  constructor(private httpService:HttpService) { 
    /*this.loggedInChange = new Observable((observer: Observer<boolean>) {
      this.loggedInChangeObserver = observer;
    });*/
    this.loggedInChange = this.loggedInSubject.asObservable();
  }

  public setIsLoggedIn(isLoggedInVal: boolean): void {
   this.loggedInSubject.next(isLoggedInVal);
  }

  public logout(){
    this.loggedInSubject.next(false);
    this.httpService.logout();
  }

}
