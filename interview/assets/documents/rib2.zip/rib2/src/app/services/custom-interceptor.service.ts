import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest,HttpHandler,HttpEvent,HttpResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError,tap } from 'rxjs/operators';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ModalComponent } from '../views/common/layout/modal.component';

@Injectable()
export class CustomInterceptor implements HttpInterceptor {
  private totalRequests = 0;
  bsModalRef: BsModalRef;
  constructor(private spinner: NgxSpinnerService,private modalService: BsModalService) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.totalRequests++;
    this.spinner.show();
     return next.handle(request).pipe(
      tap(res => {
        if (res instanceof HttpResponse) {
          this.decreaseRequests();
        }
      }),
      catchError(err => {
        this.decreaseRequests();
        if (err.status === 404 || err.status === 503 || err.status === 500 ||  err.status === 400) {
          const initialState = {
            title: 'Error Message',
            msg:"Unable to process your request!"
          };
          this.bsModalRef = this.modalService.show(ModalComponent,{initialState});
          //this.bsModalRef.content.title="Error from Interceptor;"
        }
        throw err;
      })
    );

    }

    private decreaseRequests() {
      this.totalRequests--;
      if (this.totalRequests === 0) {
        this.spinner.hide();
      }
    }
}
