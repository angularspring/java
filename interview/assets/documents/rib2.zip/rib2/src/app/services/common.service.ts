import { Injectable } from '@angular/core';
import { Conf } from '../models/conf';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  public conf:Conf;
  public user:User;
  
  constructor() { }

}
