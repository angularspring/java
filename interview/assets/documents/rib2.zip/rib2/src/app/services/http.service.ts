import { Injectable } from '@angular/core';
import { HttpClient, HttpParams} from '@angular/common/http';
import { Observable } from 'rxjs';
import { url } from './../conf/_url';
import * as CryptoJS from 'crypto-js';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private http: HttpClient) { }

  getServerDate():Observable<any>{
    return this.http.get(url.DATE_SERVICE);
  }

  getUserSecurityInfo(param:HttpParams):Observable<any>{
    return this.http.get(url.SECURE_INFO_SERVICE,{params:param});
  }

  getToken(data: string): Observable<any> {
    return this.http.get(url.USER_TOKEN_SERVICE + data);
  }

  authenticate(data:string): Observable<any> {
    return this.http.post(url.AUTH_SERVICE, data, {headers: {"Content-Type": "application/x-www-form-urlencoded"},observe: 'response'});
  }

  logout():Observable<any>{
    return this.http.post(url.LOGOUT_SERVICE,{});
  }

  getConfigurationData():Observable<any> {
    return this.http.get(url.CONF_SERVICE);
  }

  getEncryptedData(text:string,key:string):string{
    return CryptoJS.AES.encrypt(text, CryptoJS.enc.Base64.parse(key),{mode: CryptoJS.mode.ECB, padding: CryptoJS.pad.Pkcs7 }).toString();
  }

  checkFailCount(user:string):Observable<any> {
    return this.http.get(url.CHECK_FAIL_SERVICE+user);
  }

  getLastLoginDetails():Observable<any> {
    return this.http.get(url.USER_LAST_LOGIN);
  }

  /*getUsersList(): Observable<any> {
    return this.http.get(url.USER_LIST_SERVICE);
  }

  getWorkFlowInqList(data:any): Observable<any> {
    return this.http.post(url.WF_INQ_SERVICE, data);
  }

  downloadFile(data:any): Observable<any> {
    return this.http.post(url.DOWNLOAD_SERVICE, data, {responseType: "arraybuffer"});
  }

  uploadFile(data:FormData): Observable<any> {
    return this.http.post(url.UPLOAD_SERVICE, data);
   }

  uploadFileWithParam(data:FormData, param: HttpParams): Observable<any> {
    return this.http.post(environment.UPLOAD_SERVICE, data,{params:param});
   }*/

}
