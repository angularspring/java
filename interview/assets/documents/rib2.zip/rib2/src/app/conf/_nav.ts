export const navItems = [
  {
    name: 'menu.dashboard',
    url: 'dashboard',
    icon: 'icon-speedometer'
  },
  {
    name: 'menu.myhome',
    url: '/base',
    icon: 'icon-home',
    children: [
      {
        name: 'menu.aboutme',
        url: '/base/cards',
        icon: 'icon-user'
      },
      {
        name: 'menu.updateprofile',
        url: '/base/carousels',
        icon: 'fa fa-edit'
      },
      {
        name: 'menu.secinfo',
        url: '/base/collapses',
        icon: 'icon-lock'
      },
      {
        name: 'menu.conffavour',
        url: '/base/forms',
        icon: 'icon-star'
      },
      {
        name: 'menu.confsecureaccess',
        url: '/base/paginations',
        icon: 'icon-picture'
      }
    ]
  },
  {
    name: 'menu.myaccounts',
    url: '/buttons',
    icon: 'fa fa-bank',
    children: [
      {
        name: 'menu.acnlist',
        url: '/buttons/buttons',
        icon: 'fa fa-list-alt'
      },
      {
        name: 'menu.closedacnlist',
        url: '/buttons/dropdowns',
        icon: 'fa fa-list-alt'
      },
      {
        name: 'menu.accountnick',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      },
      {
        name:'menu.txnenquiry',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      },
      {
        name:'menu.acctstmt',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      },
      {
        name:'menu.opendeposit',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      },
      {
        name:'menu.deppreclosure',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      },
      {
        name:'menu.fdmatinst',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      },
      {
        name:'menu.nomdet',
        url: '/buttons/brand-buttons',
        icon: 'icon-cursor'
      }
    ]
  },
  {
    name: 'menu.fundtransfer',
    url: '/icons',
    icon: 'fa fa-rupee',
    children: [
      {
        name: 'menu.ownacct',
        url: '/icons/coreui-icons',
        icon: 'icon-star'
      },
      {
        name: 'menu.withinbank',
        url: '/icons/flags',
        icon: 'icon-star'
      },
      {
        name: 'menu.otherbank',
        url: '/icons/font-awesome',
        icon: 'icon-star'
      },
      {
        name: 'menu.quickpay',
        url: '/icons/simple-line-icons',
        icon: 'icon-star',
        badge: {
          variant: 'success',
          text: 'NEW'
        }
      },
      {
        name: 'menu.imps',
        url: '/icons/font-awesome',
        icon: 'icon-star'
      },
      {
        name: 'menu.benfdet',
        url: '/icons/font-awesome',
        icon: 'icon-star'
      },
      {
        name: 'menu.simaint',
        url: '/icons/font-awesome',
        icon: 'icon-star'
      },
      {
        name: 'menu.favtr',
        url: '/icons/font-awesome',
        icon: 'icon-star'
      }
    ]
  },
  {
    name: 'menu.services',
    url: '/notifications',
    icon: 'icon-settings',
    children: [
      {
        name: 'menu.chqservice',
        url: '/notifications/alerts',
        icon: 'icon-bell'
      },
      {
        name: 'menu.cardservices',
        url: '/notifications/badges',
        icon: 'icon-bell'
      },
      {
        name: 'menu.certificates',
        url: '/notifications/modals',
        icon: 'icon-bell'
      },
      {
        name: 'menu.estmt',
        url: '/notifications/badges',
        icon: 'icon-bell'
      },
      {
        name: 'menu.mblbank',
        url: '/notifications/modals',
        icon: 'icon-bell'
      }
    ]
  },
  {
    name: 'menu.investments',
    url: '/notifications',
    icon: 'icon-bell',
    children: [
      {
        name: 'menu.shortterm',
        url: '/notifications/alerts',
        icon: 'icon-bell'
      },
      {
        name: 'menu.longterm',
        url: '/notifications/badges',
        icon: 'icon-bell'
      }
    ]
  }

];
