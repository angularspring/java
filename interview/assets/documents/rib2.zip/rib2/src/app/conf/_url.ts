import { environment } from '../../environments/environment';
export const url={
    USER_TOKEN_SERVICE: environment.server + "RIBProducer/rest/loginUser/usersec/seckey/",
    AUTH_SERVICE: environment.server + "app/authentication",
    LOGOUT_SERVICE: environment.server + "app/logout",
    DATE_SERVICE:environment.server +"app/rest/user/getServerDate",
    SECURE_INFO_SERVICE:environment.server +"app/rest/user/getUserSecurityInfo",
    CONF_SERVICE:environment.server+"app/rest/user/getConfigurationData",
    CHECK_FAIL_SERVICE:environment.server+"app/rest/newUser/checkFailCount/",
    USER_LAST_LOGIN:environment.server+"RIBProducer/rest/loginUser/prevlogin"
};