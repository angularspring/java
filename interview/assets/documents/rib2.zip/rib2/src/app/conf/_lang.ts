export const lang=[
    {
        name:'common.english',
        code:'en',
        icon:'A'
    },
    {
        name:'common.hindi',
        code:'hi',
        icon:'अ'
    }
];