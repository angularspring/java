import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-extend',
  templateUrl: './footer-extend.component.html',
  styles: []
})
export class FooterExtendComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
