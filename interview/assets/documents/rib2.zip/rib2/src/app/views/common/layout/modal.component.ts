import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styles: []
})
export class ModalComponent implements OnInit {

  title:string;
  msg:string;

  constructor(public bsModalRef: BsModalRef) { }

  ngOnInit() {
  }

}
