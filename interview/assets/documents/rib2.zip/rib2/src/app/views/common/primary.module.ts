import { NgModule } from '@angular/core';
import { RecaptchaModule } from 'ng-recaptcha';
import { RecaptchaFormsModule } from 'ng-recaptcha/forms';
import { RECAPTCHA_SETTINGS, RecaptchaSettings } from 'ng-recaptcha';

import { SharedModule } from '../../modules/common/shared.module';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { HeaderExtendComponent } from './layout/header-extend.component';
import { FooterExtendComponent } from './layout/footer-extend.component';
import { ModalComponent } from './layout/modal.component';
import { LogoutComponent } from './login/logout.component';
import { LastloginComponent } from './layout/lastlogin.component';

@NgModule({
  declarations: [
    LoginComponent,
    DashboardComponent,
    HeaderExtendComponent,
    FooterExtendComponent,
    ModalComponent,
    LogoutComponent,
    LastloginComponent
  ],
  imports: [
    SharedModule,
    RecaptchaModule,
    RecaptchaFormsModule
  ],
  exports:[
    HeaderExtendComponent,
    FooterExtendComponent
  ],
  entryComponents:[
    LastloginComponent,
    ModalComponent
  ],
  providers:[
    {
      provide: RECAPTCHA_SETTINGS,
      useValue: { siteKey: '6LdoR3sUAAAAAKlmSSzRLDMSkzQOnZnYsf0elsZZ' } as RecaptchaSettings,
    }
  ]
})
export class PrimaryModule { }
