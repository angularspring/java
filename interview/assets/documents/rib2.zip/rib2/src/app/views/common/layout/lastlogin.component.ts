import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';

import { HttpService } from '../../../services/http.service';


@Component({
  selector: 'app-lastlogin',
  templateUrl: './lastlogin.component.html',
  styles: []
})
export class LastloginComponent implements OnInit {
  public userDetails={
    lastLoginDate:''
  };

  constructor(public bsModalRef: BsModalRef,private httpService:HttpService,
    private datePipe:DatePipe) { }

  ngOnInit() {
    this.httpService.getLastLoginDetails().subscribe((data)=>{
      this.userDetails.lastLoginDate=this.datePipe.transform(data.lastLoginDate,"dd/MM/yyyy");
    });
  }

}
