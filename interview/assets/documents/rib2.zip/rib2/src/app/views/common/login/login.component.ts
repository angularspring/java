import { Component, OnInit, ElementRef } from '@angular/core';
import { StateService } from '@uirouter/core';
import { HttpParams } from '@angular/common/http';

import { AuthenticationService } from '../../../services/authentication.service';
import { HttpService } from '../../../services/http.service';
import { CommonService } from '../../../services/common.service';
import { User } from '../../../models/user';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: []
})
export class LoginComponent implements OnInit {

  public login={
    username:'',
    password:'',
    secConfirm:false,
    flow:'',
    error:false,
    errorMsg:'',
    captcha:false,
    secureImage:'',
    secureText:'',
    captchaText:''};

  constructor(private httpService:HttpService,private state:StateService,
    private authentication:AuthenticationService,private commonService:CommonService,
    private elRef:ElementRef) { 
    
  }

  ngOnInit() {
    this.login.flow="user";
  }

  onSubmit(form:NgForm){
    this.login.error=false;
    this.login.errorMsg='';
    if(this.login.flow=='user'){
        let loginCopy:any={};
        Object.assign(loginCopy,this.login);
        form.resetForm({username:this.login.username});
        Object.assign(this.login,loginCopy);
      
        this.httpService.checkFailCount(this.login.username).subscribe((resp)=>{
          this.login.captcha=false;
        },(error)=>{
          this.login.captcha=true;
        });
        this.login.flow='pwd';
        //favourites need to be fetch from _nav.ts
        let jsonData={
          'widgets':[{'id':'userDetail','title':'User Detail','isAdded':true,'category':1},
                 {'id':"MyLiability",'title':"My Liability",'isAdded':true,'category':1},
                 {'id':"MyAsset",'title':"My Asset",'isAdded':true,'category':1},
                 {'id':"MyFav",'title':"My Favourites",'isAdded':true,'category':1},
                 {'id':"MyFavTrn",'title':"My Favourite Transaction",'isAdded':true,'category':1},
                 {'id':"MyCalender",'title':"My Calender",'isAdded':true,'category':1},
                 {'id':"MyEvents",'title':"My Events",'isAdded':true,'category':1}],
          'favorites':[{'id':"dashboard",'isAdded':false},{'id':"dashboard1",'isAdded':false},
                   {'id':"dashboard2",'isAdded':false},{'id':"dashboard3",'isAdded':false},
                   {'id':"dashboard4",'isAdded':false},{'id':"dashboard5",'isAdded':false},
                   {'id':"dashboard6",'isAdded':false},{'id':"dashboard7",'isAdded':false},
                   {'id':"dashboard8",'isAdded':false},{'id':"about",'isAdded':false},
                   {'id':"updateProfile",'isAdded':true,"value":5},{'id':"scrtyInfo.view",'isAdded':false},
                   {'id':"configureSecureLoginAccess",'isAdded':false},{'id':"configureHomePage",'isAdded':false},
                   {'id':"configureBackground",'isAdded':false},{'id':"configurePrimaryAccount",'isAdded':false},
                   {'id':"acnList",'isAdded':true,"value":1},{'id':"closedAcnList",'isAdded':false},
                   {'id':"acnNickName",'isAdded':false},{'id':"txnEnquiry",'isAdded':false},
                   {'id':"acctStmt",'isAdded':true,"value":2},{'id':"asba.options",'isAdded':false},
                   {'id':"deposit.openFDHome",'isAdded':true,"value":4},{'id':"depClosure.home",'isAdded':false},
                   {'id':"fdMaturity.home",'isAdded':false},{'id':"nominee.home",'isAdded':false},{'id':"ownFd.ownAcnTransfer",'isAdded':false},{'id':"thirdFd.thirdPtyTrnsfrInFIS",'isAdded':false},{'id':"neftRtgs.home",'isAdded':false},{'id':"quickPay.transferTypes",'isAdded':false},{'id':"quickPayLimits.home",'isAdded':false},{'id':"imps.list",'isAdded':false},{'id':"beneficiary.options",'isAdded':true,"value":3},{'id':"fundTrnsfrEnquiry",'isAdded':false},{'id':"stMaintenance.home",'isAdded':false},{'id':"favouriteTransaction",'isAdded':false},{'id':"updTransLimit.home",'isAdded':false},{'id':"impsAadhaar.home",'isAdded':false},{'id':"chqServices",'isAdded':true,"value":8},{'id':"cardPinServices",'isAdded':true,"value":7},{'id':"aadhaar.home",'isAdded':false},{'id':"PMinsurance.Home",'isAdded':false},{'id':"certificates",'isAdded':false},{'id':"estmt.home",'isAdded':true,"value":6},{'id':"mBank.home",'isAdded':false},{'id':"shortTerm",'isAdded':false},{'id':"longTerm",'isAdded':false}],
          'username':this.login.username
        };
        let jsonString:string=JSON.stringify(jsonData);
        let param:HttpParams=new HttpParams ;
        param=param.append("username",this.login.username).append("wdgtJSON",jsonString);
        this.httpService.getUserSecurityInfo(param).subscribe((resp)=>{
          if(resp!=null){
            let user:User=new User();
            user.setSecureText(resp.secText);
            user.setSecureImage(resp.secImage);
            user.setResetLoginPass(resp.resetLoginPass);
            user.setResetTxnPass(resp.resetTxnPass);
            user.setResetTxnPassFirst(resp.resetTxnPassFirst);
            if(resp.themeData && resp.themeData!=""){
              user.setThemeData(JSON.parse(resp.themeData));
            }
            else {
              user.setThemeData("");
            }
            if(resp.menuDetails && resp.menuDetails!=""){
              user.setMenuDetails(JSON.parse(resp.menuDetails));
            }
            else {
              user.setMenuDetails("");
            }
            if (resp.theme !=null) {
            user.setTheme(resp.theme);
          }
          else {
            user.setTheme("");
          }
          this.commonService.user=user;
          this.login.secureText=resp.secText;
          let secImage:string=resp.secImage;
          let loginImgArray:string[]=secImage.split('_');
          if(loginImgArray.length==2){
            secImage=loginImgArray[0]; 
          }
          this.login.secureImage='assets/img/secure_images/'+secImage+'.jpg';
        }
      });
    }
    else{
      if(this.login.captcha==true && this.login.captchaText==''){
        this.login.error=true;
        this.login.errorMsg="Please verify the reCaptcha!"
        return;
        
      }
      else if(this.login.secureText!='' && this.login.secConfirm==false){
        this.login.error=true;
        this.login.errorMsg="Please confirm the security image & text!";
        return;
      }
      else {
        this.login.captchaText='';
        let tokenData = this.login.username;
        this.httpService.getToken(tokenData).subscribe( (response) => {
          let encrypted_pwd = this.httpService.getEncryptedData(this.login.password,response[0]);
          encrypted_pwd = encrypted_pwd.replace(/\+/g,'AB1')           

          let data ="j_username=" + this.login.username +"&j_password=" + encrypted_pwd +"&_spring_security_remember_me=&submit=Login";        
          this.httpService.authenticate(data).subscribe( (resp) => {
            console.log(resp);
            this.authentication.setIsLoggedIn(true);
            this.state.go("dashboard");
          },(error)=>{
            console.log(error);
            this.login.error=true;
            //check fail count to display reCaptcha
            this.httpService.checkFailCount(this.login.username).subscribe((resp)=>{
              this.login.captcha=false;
            },(error)=>{
              this.login.captcha=true;
            });
            if(error.status=="428"){
              this.login.errorMsg="Invalid User id or Password";
            }
            else if(error.status=="423"){
              this.login.errorMsg="Login Failure - Exceeded Maximum Attempts";
            }
            else if(error.status=="420"){
              this.login.errorMsg="Login Failure - UserId is blocked";
            }
            else if(error.status=="440"){
              this.login.errorMsg="Login Failure - Not a Registered User";
            }
            else if(error.status=="444"){
              this.login.errorMsg="Error in login, Contact Bank";
            }
            else if(error.status=="426"){
              this.login.errorMsg="UserId is blocked,Contact Bank";
            }
            else if(error.status=="429"){
              this.login.errorMsg="UserId is inactive,Contact Bank";
            }
            else if(error.status=="421"){
              this.login.errorMsg="Your last session was terminated incorrectly or is currently active . Please try logging in again after some time.";
            }
            else if(error.status=="498"){
              this.login.errorMsg="Please check the security image to proceed";
            }
          });
        });
      }
    }
  }

  backToHome(){
    this.state.reload();
  }
}
