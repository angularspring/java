import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { StateService } from '@uirouter/core';
import { BsModalService,BsModalRef } from 'ngx-bootstrap/modal';

import { AuthenticationService } from '../../../services/authentication.service';
import { lang } from '../../../conf/_lang';
import { LastloginComponent } from './lastlogin.component';


@Component({
  selector: 'app-header-extend',
  templateUrl: './header-extend.component.html',
  styles: []
})
export class HeaderExtendComponent implements OnInit {

  public lang=lang;
  public authData:any={};

  constructor(private authentication:AuthenticationService,private translate:TranslateService,
    private state:StateService,private modalService: BsModalService) { }

  ngOnInit(){
    this.authentication.loggedInChange.subscribe((data) => {
      this.authData.isLoggedIn = data;
    }); 
  }

  changeLanguage(lang){
    this.translate.use(lang);
  }

  onLogout(){
    this.authentication.logout();
    this.state.go('logout');
  }

  showLastLogin(){
    let bsModel:BsModalRef;
    bsModel=this.modalService.show(LastloginComponent);
  }

}
