export class Conf {
    private serverDate:string;
    private regenerateOTPTimer:number;
    private allowedOTPAttemps:number;
    private regenerateRefNumberAttempts:number;
    private regenerateATMRefTimer:number;
    private allowedTxnPwdAttemps:number;
    private isTransPwdConfirmation:boolean;

    setServerDate(date:string){
        this.serverDate=date;
    }
    getServerDate():string{
        return this.serverDate;
    }

    setOtpTimer(timer:number){
        this.regenerateOTPTimer=timer;
    }
    getOtpTimer():number{
        return this.regenerateOTPTimer;
    }

    setOtpAttempts(attempt:number){
        this.allowedOTPAttemps=attempt;
    }
    getOtpAttempts():number{
        return this.allowedOTPAttemps;
    }

    setRefNumAttempts(attempts:number){
        this.regenerateRefNumberAttempts=attempts;
    }
    getRefNumAttempts():number{
        return this.regenerateRefNumberAttempts;
    }

    setAtmRefTimer(timer:number){
        this.regenerateATMRefTimer=timer;
    }
    getAtmRefTimer():number{
        return this.regenerateATMRefTimer;
    }

    setTranPwdAttempts(attempts:number){
        this.allowedTxnPwdAttemps=attempts;
    }
    getTranPwdAttempts():number{
        return this.allowedTxnPwdAttemps;
    }

    setTranPwdConfirm(confirm:boolean){
        this.isTransPwdConfirmation=confirm;
    }
    isTranPwdConfirm():boolean{
        return this.isTransPwdConfirmation;
    }
}
