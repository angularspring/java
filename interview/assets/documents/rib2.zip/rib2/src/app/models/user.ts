export class User {
    private secureText:string;
    private secureImage:string;
    private resetLoginPass:boolean;
    private resetTxnPass:boolean;
    private resetTxnPassFirst:boolean;
    private themeData:any;
    private menuDetails:any;
    private theme:string;

    setSecureText(text:string){
        this.secureText=text;
    }
    getSecureText():string{
        return this.secureText;
    }
    setSecureImage(text:string){
        this.secureImage=text;
    }
    getSecureImage():string{
        return this.secureImage;
    }
    setResetLoginPass(text:boolean){
        this.resetLoginPass=text;
    }
    getResetLoginPass():boolean{
        return this.resetLoginPass;
    }
    setResetTxnPass(text:boolean){
        this.resetTxnPass=text;
    }
    getResetTxnPass():boolean{
        return this.resetTxnPass;
    }
    setResetTxnPassFirst(text:boolean){
        this.resetTxnPassFirst=text;
    }
    getResetTxnPassFirst():boolean{
        return this.resetTxnPassFirst;
    }
    setThemeData(theme:any){
        this.themeData=theme;
    }
    getThemeData():any{
        return this.themeData;
    }
    setMenuDetails(menu:any){
        this.menuDetails=menu;
    }
    getMenuDetails():any{
        return this.menuDetails;
    }
    setTheme(theme:string){
        this.theme=theme;
    }
    getTheme():string{
        return this.theme;
    }
}