import { Component, OnInit, ElementRef, Input } from '@angular/core';

@Component({
  selector: 'app-sidebar-nav-item-extend',
  template: `
  <li *ngIf="!isDropdown(); else dropdown" [ngClass]="hasClass() ? 'nav-item ' + item.class : 'nav-item'">
      <app-sidebar-nav-link-extend [link]='item'></app-sidebar-nav-link-extend>
    </li>
    <ng-template #dropdown>
      <li [ngClass]="hasClass() ? 'nav-item nav-dropdown ' + item.class : 'nav-item nav-dropdown'"
          [class.open]="isActive()"
          uiSrefActive="open"
          appNavDropdown>
        <app-sidebar-nav-dropdown-extend [link]='item'></app-sidebar-nav-dropdown-extend>
      </li>
    </ng-template>
    `
})
export class SidebarNavItemExtendComponent implements OnInit {

  @Input() item;
  constructor(private elRef:ElementRef) {  }

  ngOnInit() {
    //console.log(this.elRef);
    var nativeElement: HTMLElement = this.elRef.nativeElement,
            parentElement: HTMLElement = nativeElement.parentElement;
        // move all children out of the element
        while (nativeElement.firstChild) {
            parentElement.insertBefore(nativeElement.firstChild, nativeElement);
        }
        // remove the empty element(the host)
        parentElement.removeChild(nativeElement);
  }

  hasClass() {
    return this.item.class ? true : false;
  }

  isDropdown() {
    return this.item.children ? true : false;
  }

  thisUrl() {
    return this.item.url;
  }

  isActive() {
    return false;
    //return this.router.isActive(this.thisUrl(), false);
  }
}
