import { Component, OnInit, Input, ElementRef } from '@angular/core';

@Component({
  selector: 'app-sidebar-nav-link-extend',
  template:`<a *ngIf="!isExternalLink(); else external"
    [ngClass]="hasVariant() ? 'nav-link nav-link-' + link.variant : 'nav-link'"
    uiSrefActive="active"
    [uiSref]="link.url"
    (click)="hideMobile()">
    <i *ngIf="isIcon()" class="nav-icon {{ link.icon }}"></i>
    {{ link.name|translate }}
    <span *ngIf="isBadge()" [ngClass]="'badge badge-' + link.badge.variant">{{ link.badge.text }}</span>
  </a>
  <ng-template #external>
    <a [ngClass]="hasVariant() ? 'nav-link nav-link-' + link.variant : 'nav-link'" href="{{link.url}}">
      <i *ngIf="isIcon()" class="nav-icon {{ link.icon }}"></i>
      {{ link.name|translate }}
      <span *ngIf="isBadge()" [ngClass]="'badge badge-' + link.badge.variant">{{ link.badge.text }}</span>
    </a>
  </ng-template>
  `
})
export class SidebarNavLinkExtendComponent implements OnInit {

  @Input() link;
  constructor(private elRef:ElementRef) { }

  ngOnInit() {
    
  }

  hasVariant() {
    return this.link.variant ? true : false;
  }

  isBadge() {
    return this.link.badge ? true : false;
  }
  isExternalLink() {
    return this.link.url.substring(0, 4) === 'http' ? true : false;
  }
  isIcon() {
    return this.link.icon ? true : false;
  }

  hideMobile() {
    if (document.body.classList.contains('sidebar-show')) {
        document.body.classList.toggle('sidebar-show');
    }
  }
}
