import { NgModule } from '@angular/core';
import { RootModule, UIRouterModule } from '@uirouter/angular';
import { LoginComponent } from '../../views/common/login/login.component';
import { DashboardComponent } from '../../views/common/dashboard/dashboard.component';
import { LogoutComponent } from 'src/app/views/common/login/logout.component';

const rootModule: RootModule = {
  states: [
    {
      name: "login",
      url: "/",
      component: LoginComponent
    },
    {
      name: "logout",
      component: LogoutComponent
    },
    {
      name: "dashboard",
      component: DashboardComponent
    }
  ],
  useHash: true,
  otherwise:"/"
};

@NgModule({
  imports: [UIRouterModule.forRoot(rootModule)],
  exports: [UIRouterModule]
})
export class AppRoutingModule { }