import { Component, OnInit, ElementRef, Input } from '@angular/core';

@Component({
  selector: 'app-sidebar-nav-dropdown-extend',
  template: `<a class="nav-link nav-dropdown-toggle" appNavDropdownToggle>
    <i *ngIf="isIcon()" class="nav-icon {{ link.icon }}"></i>
    {{ link.name|translate }}
    <span *ngIf="isBadge()" [ngClass]="'badge badge-' + link.badge.variant">{{ link.badge.text }}</span>
  </a>
  <ul class="nav-dropdown-items">
    <ng-template ngFor let-child [ngForOf]="link.children">
      <app-sidebar-nav-item-extend [item]='child'></app-sidebar-nav-item-extend>
    </ng-template>
  </ul>
  `,
  styles: ['.nav-dropdown-toggle { cursor: pointer; }']
})
export class SidebarNavDropdownExtendComponent implements OnInit {

  @Input() link;
  constructor(private elRef:ElementRef) { }

  ngOnInit() {
    var nativeElement: HTMLElement = this.elRef.nativeElement,
            parentElement: HTMLElement = nativeElement.parentElement;
        // move all children out of the element
        while (nativeElement.firstChild) {
            parentElement.insertBefore(nativeElement.firstChild, nativeElement);
        }
        // remove the empty element(the host)
        parentElement.removeChild(nativeElement);
  }
  isIcon() {
    return this.link.icon ? true : false;
  }
  isBadge() {
    return this.link.badge ? true : false;
  }

}
