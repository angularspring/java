import { Component, OnInit, Input, HostBinding } from '@angular/core';
import { navItems } from '../../conf/_nav';

@Component({
  selector: 'app-sidebar-nav-extend',
  template: `<ul class="nav">
  <ng-template ngFor let-navitem [ngForOf]="navItems">
    <li *ngIf="isDivider(navitem)" class="nav-divider"></li>
    <ng-template [ngIf]="isTitle(navitem)">
      <app-sidebar-nav-title [title]='navitem'></app-sidebar-nav-title>
    </ng-template>
    <ng-template [ngIf]="!isDivider(navitem)&&!isTitle(navitem)">
      <app-sidebar-nav-item-extend [item]='navitem'></app-sidebar-nav-item-extend>
    </ng-template>
  </ng-template>
</ul>`,
  styles: []
})
export class SidebarNavExtendComponent implements OnInit {

  @Input() navItems;
  @HostBinding('class.sidebar-nav') setClass:boolean =true;
  @HostBinding('attr.role') role:string;

  constructor() { 
    this.role = 'nav';
  }

  ngOnInit() {
  }

  isTitle(item) {
        return item.title ? true : false;
  }

  isDivider(item) {
    return item.divider ? true : false;
  }
}
