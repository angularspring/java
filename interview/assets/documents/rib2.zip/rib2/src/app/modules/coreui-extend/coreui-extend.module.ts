import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AppSidebarModule } from '@coreui/angular';
import { AppRoutingModule } from '../common/app-routing.module';
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';

import { SidebarNavExtendComponent } from './sidebar-nav-extend.component';
import { SidebarNavItemExtendComponent } from './sidebar-nav-item-extend.component';
import { SidebarNavLinkExtendComponent } from './sidebar-nav-link-extend.component';
import { SidebarNavDropdownExtendComponent } from './sidebar-nav-dropdown-extend.component';

@NgModule({
  declarations: [SidebarNavExtendComponent, SidebarNavItemExtendComponent, SidebarNavLinkExtendComponent, SidebarNavDropdownExtendComponent],
  imports: [
    CommonModule,
    AppSidebarModule,
    AppRoutingModule,
    TranslateModule
  ],
  exports:[
    SidebarNavExtendComponent
  ]
})
export class CoreuiExtendModule { }
