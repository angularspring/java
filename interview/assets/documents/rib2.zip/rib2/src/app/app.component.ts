import { Component } from '@angular/core';
import { StateService } from '@uirouter/core';

import { navItems } from './conf/_nav';
import { AuthenticationService } from './services/authentication.service';
import { TranslateService } from '@ngx-translate/core';
import { HttpService } from './services/http.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})
export class AppComponent {
  title = 'rib';
  public authData:any = {};
  public navItems = navItems
  public sidebarMinimized = true;
  private changes: MutationObserver;
  public element: HTMLElement = document.body;
  
  constructor(private state:StateService,
    private authentication:AuthenticationService,
    private translate:TranslateService,private httpService:HttpService) {

    translate.setDefaultLang('en');

    this.changes = new MutationObserver((mutations) => {
      this.sidebarMinimized = document.body.classList.contains('sidebar-minimized');
    });

    this.changes.observe(<Element>this.element, {
      attributes: true
    });
  }

  ngOnInit(){
    this.httpService.getServerDate().subscribe((resp)=>{
      console.log(resp.serverDate);
    },
    (error)=>{
      console.log("MTM not connected");
    });

    this.authentication.loggedInChange.subscribe((data) => {
      this.authData.isLoggedIn = data;
    }); 
  }
}
